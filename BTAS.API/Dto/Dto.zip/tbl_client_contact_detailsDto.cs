﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace BTAS.API.Dto
{
	public class tbl_client_contact_detailsDto
	{
		[JsonProperty("Id")]
		[DoNotInclude]
		public int idtbl_client_contact_details { get; set; }
		[StringLength(50)]
		[JsonProperty("FirstName")]
		[Description("Contact details first name")]
		public string tbl_client_contact_details_first_name { get; set; }
		[StringLength(50)]
		[JsonProperty("LastName")]
		[Description("Contact details last name")]
		public string tbl_client_contact_details_last_name { get; set; }
		[StringLength(50)]
		[JsonProperty("ContactNumber")]
		[Description("Contact details telephone or mobile number")]
		public string tbl_client_contact_details_tel { get; set; }
		[StringLength(50)]
		[JsonProperty("Email")]
		[Description("Contact details email address")]
		public string tbl_client_contact_details_email { get; set; }
		[StringLength(50)]
		[JsonProperty("Position")]
		[Description("Contact details position or title")]
		public string tbl_client_contact_details_position { get; set; }
		[StringLength(50)]
		[JsonProperty("Type")]
		[Description("Contact details type")]
		[RegularExpression("Staff|Service")]
		public string tbl_client_contact_details_type { get; set; }
		[JsonProperty("IsActive")]
		[Description("Contact details active or inactive")]
		[RegularExpression("true|false")]
		public bool? tbl_client_contact_details_active { get; set; } = true;
		[JsonProperty("HeaderId")]
		[Description("Set Client Header Id to link/relate this contact details")]
		public int? tbl_client_header_id { get; set; }
		[JsonProperty("ClientHeader")]
		[DoNotInclude]
		public virtual tbl_client_headerDto tbl_client_header { get; set; }
		[JsonProperty("ContactGroups")]
		[DoNotInclude]
		public virtual ICollection<tbl_client_contact_groupDto> contactGroups { get; set; } = new Collection<tbl_client_contact_groupDto>();
	}
}
