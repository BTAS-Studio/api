﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.ComponentModel;

namespace BTAS.API.Dto
{
    public class tbl_containerDto
    {
        //[JsonProperty("Id")]
        //public int idtbl_container { get; set; }
        [JsonProperty("ContainerNumber")]
        [StringLength(30)]
        [Description("Container reference number")]
        public string tbl_container_number { get; set; }

        [StringLength(50)]
        [JsonProperty("Status")]
        [Description("Container current status")]
        public string tbl_container_status { get; set; }

        [JsonProperty("Quantity")]
        [Description("Container quantity")]
        public int tbl_container_qty { get; set; }
        [StringLength(30)]
        [JsonProperty("SealNumber")]
        [Description("Container seal number")]
        public string tbl_container_sealNumber { get; set; }
        [StringLength(30)]
        [JsonProperty("Mode")]
        [Description("Container mode")]
        public string tbl_container_mode { get; set; }
        [StringLength(30)]
        [JsonProperty("Type")]
        [Description("Container type")]
        public string tbl_container_type { get; set; }
        [JsonProperty("GrossWeight")]
        [Description("Container gross weight")]
        public decimal tbl_container_grossWeight { get; set; }
        [JsonProperty("CreatedDate")]
        [DoNotInclude]
        public DateTime tbl_container_createdDate { get; set; }
        [StringLength(30)]
        [JsonProperty("SealedBy")]
        [Description("Person who sealed the container")]
        public string tbl_container_sealedBy { get; set; }
        
        [JsonProperty("MawbId")]
        [DoNotInclude]
        public int? tbl_mawb_id { get; set; }
        [StringLength(30)]
        [JsonProperty("MawbNumber")]
        [Description("Master waybill linked to this container")]
        public string MawbNumber { get; set; }
        [JsonProperty("MAWB")]
        [Description("Json array of Master waybill linked to this container")]
        public virtual tbl_mawbDto tbl_mawb { get; set; }
        [DoNotInclude]
        public ICollection<tbl_hawbDto> hawbs { get; set; } = new Collection<tbl_hawbDto>();
    }
}
