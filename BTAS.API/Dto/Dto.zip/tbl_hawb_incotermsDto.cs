﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace BTAS.API.Dto
{
	public class tbl_hawb_incotermsDto
	{
		[JsonProperty("Id")]
		public int idtbl_hawb_incoterms { get; set; }
		[StringLength(50)]
		[JsonProperty("IncotermsCode")]
		public string tbl_hawb_incoterms_code { get; set; }
		[StringLength(150)]
		[JsonProperty("Description")]
		public string tbl_hawb_incoterms_description { get; set; }

		[JsonProperty("HawbId")]
		public int? tbl_hawb_id { get; set; }
		[JsonProperty("HawbNumber")]
		public string HawbNumber { get; set; }
		[JsonProperty("HAWB")]
		public virtual tbl_hawbDto hawb { get; set; }
	}
}
