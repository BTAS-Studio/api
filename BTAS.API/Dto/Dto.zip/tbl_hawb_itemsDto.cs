﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace BTAS.API.Dto
{
	public class tbl_hawb_itemsDto
	{
		[JsonProperty("Id")]
		public int idtbl_hawb_items { get; set; }
		
		[JsonProperty("Weight")]
		public decimal tbl_hawb_items_weight { get; set; }
		[JsonProperty("Length")]
		public decimal tbl_hawb_items_length { get; set; }
		[JsonProperty("Width")]
		public decimal tbl_hawb_items_width { get; set; }
		[JsonProperty("Height")]
		public decimal tbl_hawb_items_height { get; set; }
		[StringLength(50)]
		[JsonProperty("WeightUnit")]
		public string tbl_hawb_items_weightUnit { get; set; }
		[StringLength(50)]
		[JsonProperty("LengthUnit")]
		public string tbl_hawb_items_lenghtUnit { get; set; }
		[JsonProperty("Dg")]
		public byte tbl_hawb_items_dg { get; set; }
		[StringLength(150)]
		[JsonProperty("Description")]
		public string tbl_hawb_items_description { get; set; }
		[StringLength(50)]
		[JsonProperty("Type")]
		public string tbl_hawb_items_type { get; set; }
		[JsonProperty("Quantity")]
		public int tbl_hawb_items_qty { get; set; }

		[JsonProperty("HawbId")]
		[DoNotInclude]
		public int? tbl_hawb_id { get; set; }
		[StringLength(30)]
		[JsonProperty("HawbNumber")]
		[DoNotInclude]
		public string HawbNumber { get; set; }
		[JsonProperty("HAWB")]
		[DoNotInclude]
		public virtual tbl_hawbDto tbl_hawb { get; set; }

		[DoNotInclude]
		public int? tbl_items_sku_id { get; set; }
		[StringLength(30)]
		[JsonProperty("SKUCode")]
		public string SkuCode { get; set; }
		[JsonProperty("SKU")]
		[DoNotInclude]
		public virtual tbl_items_skuDto tbl_items_sku { get; set; }
	}
}
