﻿using BTAS.Data.Models;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace BTAS.API.Dto
{
    public class tbl_items_skuDto
    {
		[JsonProperty("SKU")]
		public int idtbl_items_sku { get; set; }
		[StringLength(50)]
		[JsonProperty("WeightUnit")]
		public string tbl_items_weightUnit { get; set; }
		[JsonProperty("Weight")]
		public decimal tbl_items_weight { get; set; }
		[StringLength(50)]
		[JsonProperty("DimensionUnit")]
		public string tbl_items_dimensionUnit { get; set; }
		[JsonProperty("Length")]
		public decimal tbl_items_length { get; set; }
		[JsonProperty("Width")]
		public decimal tbl_items_width { get; set; }
		[JsonProperty("Height")]
		public decimal tbl_items_height { get; set; }
		[JsonProperty("Volume")]
		public decimal tbl_items_volume { get; set; }
		[JsonProperty("Number")]
		public int tbl_items_number { get; set; }
		[StringLength(30)]
		[JsonProperty("SKUCode")]
		public string tbl_items_skuCode { get; set; }
		[StringLength(150)]
		[JsonProperty("Description")]
		public string tbl_items_description { get; set; }
		[StringLength(150)]
		[JsonProperty("NativeDescription")]
		public string tbl_items_nativeDescription { get; set; }
		[StringLength(50)]
		[JsonProperty("HsCode")]
		public string tbl_items_hsCode { get; set; }
		[StringLength(50)]
		[JsonProperty("OriginCountry")]
		public string tbl_items_originCountry { get; set; }
		[JsonProperty("Value")]
		public decimal tbl_items_value { get; set; }
		[StringLength(50)]
		[JsonProperty("ProductUrl")]
		public string tbl_items_productUrl { get; set; }
		[StringLength(50)]
		[JsonProperty("BatteryType")]
		public string tbl_items_batteryType { get; set; }
		[StringLength(50)]
		[JsonProperty("BatteryPacking")]
		public string tbl_items_batteryPacking { get; set; }
		[JsonProperty("IsDangerousGoods")]
		public bool? tbl_items_dangerousGoods { get; set; }
		[StringLength(50)]
		[JsonProperty("BatchNumber")]
		public string tbl_items_batchNumber { get; set; }
	}
}
