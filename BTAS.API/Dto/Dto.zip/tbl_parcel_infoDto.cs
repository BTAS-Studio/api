﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace BTAS.API.Dto
{
    public class tbl_parcel_infoDto
    {
		//[JsonProperty("Id")]
		//public int idtbl_parcel_info { get; set; }
		[JsonProperty("ParcelInfoNumber")]
		[StringLength(30)]
		public string tbl_parcel_info_number { get; set; }
		[JsonProperty("Status")]
		[StringLength(30)]
		public string tbl_parcel_info_status { get; set; }

		[StringLength(50)]
		[JsonProperty("BatchId")]
		public string tbl_parcel_info_batchId { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperId")]
		public string tbl_parcel_info_shipperId { get; set; }
		[StringLength(50)]
		[JsonProperty("TrackingNumber")]
		public string tbl_parcel_info_trackingNo { get; set; }
		[StringLength(50)]
		[JsonProperty("ReferenceNumber")]
		public string tbl_parcel_info_referenceNo { get; set; }
		[StringLength(150)]
		[JsonProperty("DeliveryAddressLine1")]
		public string tbl_parcel_info_deliveryAddressLine1 { get; set; }
		[StringLength(150)]
		[JsonProperty("DeliveryAddressLine2")]
		public string tbl_parcel_info_deliveryAddressLine2 { get; set; }
		[StringLength(150)]
		[JsonProperty("DeliveryAddressLine3")]
		public string tbl_parcel_info_deliveryAddressLine3 { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryCity")]
		public string tbl_parcel_info_deliveryCity { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryCountry")]
		public string tbl_parcel_info_deliveryCountry { get; set; }
		[StringLength(150)]
		[JsonProperty("Description")]
		public string tbl_parcel_info_description { get; set; }
		[StringLength(150)]
		[JsonProperty("NativeDescription")]
		public string tbl_parcel_info_nativeDescription { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryEmail")]
		public string tbl_parcel_info_deliveryEmail { get; set; }
		[StringLength(50)]
		[JsonProperty("Facility")]
		public string tbl_parcel_info_facility { get; set; }
		[StringLength(150)]
		[JsonProperty("Instructions")]
		public string tbl_parcel_info_instruction { get; set; }
		[StringLength(50)]
		[JsonProperty("InvoiceCurrency")]
		public string tbl_parcel_info_invoiceCurrency { get; set; }
		[JsonProperty("InvoiceValue")]
		public decimal? tbl_parcel_info_invoiceValue { get; set; }
		[StringLength(50)]
		[JsonProperty("Phone")]
		public string tbl_parcel_info_phone { get; set; }
		[StringLength(50)]
		[JsonProperty("Platform")]
		public string tbl_parcel_info_platform { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliverySuburb")]
		public string tbl_parcel_info_deliverySuburb { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryPostcode")]
		public string tbl_parcel_info_deliveryPostcode { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryCompany")]
		public string tbl_parcel_info_deliveryCompany { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryMoney")]
		public string tbl_parcel_info_deliveryName { get; set; }
		[StringLength(50)]
		[JsonProperty("ServiceCode")]
		public string tbl_parcel_info_serviceCode { get; set; }
		[StringLength(50)]
		[JsonProperty("ServiceOption")]
		public string tbl_parcel_info_serviceOption { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryState")]
		public string tbl_parcel_info_deliveryState { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperName")]
		public string tbl_parcel_info_shipperName { get; set; }
		[StringLength(150)]
		[JsonProperty("ShipperAddressLine1")]
		public string tbl_parcel_info_shipperAddressLine1 { get; set; }
		[StringLength(150)]
		[JsonProperty("ShipperAddressLine2")]
		public string tbl_parcel_info_shipperAddressLine2 { get; set; }
		[StringLength(150)]
		[JsonProperty("ShipperAddressLine3")]
		public string tbl_parcel_info_shipperAddressLine3 { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperCity")]
		public string tbl_parcel_info_shipperCity { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperState")]
		public string tbl_parcel_info_shipperState { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperPostcode")]
		public string tbl_parcel_info_shipperPostcode { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperCountry")]
		public string tbl_parcel_info_shipperCountry { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperPhone")]
		public string tbl_parcel_info_shipperPhone { get; set; }
		[JsonProperty("HasAuthorityToLeave")]
		public bool? tbl_parcel_info_authorityToLeave { get; set; } = false;
		[StringLength(50)]
		[JsonProperty("Incoterms")]
		public string tbl_parcel_info_incoterm { get; set; }
		[StringLength(50)]
		[JsonProperty("VendorId")]
		public string tbl_parcel_info_vendorid { get; set; }
		[JsonProperty("GetExemptionCode")]
		public bool? tbl_parcel_info_gstexemptioncode { get; set; } = false;
		[StringLength(50)]
		[JsonProperty("ABNNumber")]
		public string tbl_parcel_info_abnnumber { get; set; }
		[StringLength(50)]
		[JsonProperty("SortCode")]
		public string tbl_parcel_info_sortCode { get; set; }
		[JsonProperty("CoverAmount")]
		public decimal? tbl_parcel_info_coveramount { get; set; }
		[StringLength(50)]
		[JsonProperty("OrderItems")]
		public string tbl_parcel_info_orderItems { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryInstructions")]
		public string tbl_parcel_info_deliveryInstructions { get; set; }
		[JsonProperty("LockerService")]
		public bool? tbl_parcel_info_lockerService { get; set; }
		[StringLength(50)]
		[JsonProperty("ReturnName")]
		public string tbl_parcel_info_returnName { get; set; }
		[StringLength(150)]
		[JsonProperty("ReturnAddressLine1")]
		public string tbl_parcel_info_returnAddress1 { get; set; }
		[StringLength(150)]
		[JsonProperty("ReturnAddressLine2")]
		public string tbl_parcel_info_returnAddress2 { get; set; }
		[StringLength(150)]
		[JsonProperty("ReturnAddressLine3")]
		public string tbl_parcel_info_returnAddress3 { get; set; }
		[StringLength(50)]
		[JsonProperty("ReturnCity")]
		public string tbl_parcel_info_returnCity { get; set; }
		[StringLength(50)]
		[JsonProperty("ReturnState")]
		public string tbl_parcel_info_returnState { get; set; }
		[StringLength(50)]
		[JsonProperty("ReturnPostcode")]
		public string tbl_parcel_info_returnPostcode { get; set; }
		[StringLength(50)]
		[JsonProperty("ReturnCountry")]
		public string tbl_parcel_info_returnCountry { get; set; }
		[StringLength(50)]
		[JsonProperty("ReturnOption")]
		public string tbl_parcel_info_returnOption { get; set; }
		[StringLength(50)]
		[JsonProperty("ParcelItemsInfo")]
		public string tbl_parcel_info_parcelItems { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperEmail")]
		public string tbl_parcel_info_shipperEmail { get; set; }
		[StringLength(50)]
		[JsonProperty("Shipment")]
		public string tbl_parcel_info_shipment { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryContact")]
		public string tbl_parcel_info_deliveryContact { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryContactPhone")]
		public string tbl_parcel_info_deliveryContactPhone { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryContactEmail")]
		public string tbl_parcel_info_deliveryContactEmail { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperSuburb")]
		public string tbl_parcel_info_shipperSuburb { get; set; }
		[StringLength(50)]
		[JsonProperty("DeliveryPhone")]
		public string tbl_parcel_info_deliveryPhone { get; set; }
		[StringLength(150)]
		[JsonProperty("ShipperInstructions")]
		public string tbl_parcel_info_shipperInstructions { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperContact")]
		public string tbl_parcel_info_shipperContact { get; set; }
		[StringLength(50)]
		[JsonProperty("Warehouse")]
		public string tbl_parcel_info_warehouse { get; set; }

		[JsonProperty("Timestamp")]
		public DateTime? tbl_parcel_info_timestamp { get; set; }
		[JsonProperty("ReadyDate")]
		public DateTime? tbl_parcel_info_readyDate { get; set; }
		[JsonProperty("DG")]
		public bool? tbl_parcel_info_dg { get; set; } = false;
		[StringLength(50)]
		[JsonProperty("DGClass")]
		public string tbl_parcel_info_dgClass { get; set; }
		[StringLength(50)]
		[JsonProperty("DGUn")]
		public string tbl_parcel_info_dgUn { get; set; }
		[StringLength(50)]
		[JsonProperty("DGPackaging")]
		public string tbl_parcel_info_dgPackaging { get; set; }
		[JsonProperty("TailLiftOrigin")]
		public bool? tbl_parcel_info_tailLiftO { get; set; } = false;
		[JsonProperty("TailLiftDestionation")]
		public bool? tbl_parcel_info_tailLiftD { get; set; } = false;
		[StringLength(50)]
		[JsonProperty("ShipperCompany")]
		public string tbl_parcel_info_shipperCompany { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperLastname")]
		public string tbl_parcel_info_shipperLastName { get; set; }
		[JsonProperty("DeliveryDate")]
		public DateTime? tbl_parcel_info_deliveryDate { get; set; }

		[JsonProperty("ReceptacleId")]
		public int? tbl_receptacle_id { get; set; }
		[JsonProperty("ReceptacleNumber")]
		[StringLength(30)]
		public string ReceptacleNumber { get; set; }
		[JsonProperty("Receptacle")]
		public virtual tbl_receptacleDto receptacle { get; set; }

		public ICollection<tbl_parcel_itemsDto> parcelItems { get; set; } = new Collection<tbl_parcel_itemsDto>();
	}
}
