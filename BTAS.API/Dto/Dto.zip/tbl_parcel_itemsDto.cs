﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace BTAS.API.Dto
{
    public class tbl_parcel_itemsDto
    {
		[JsonProperty("Id")]
		public int idtbl_parcel_items { get; set; }

		[JsonProperty("Weight")]
		public decimal tbl_parcel_items_parcelWeight { get; set; }
		[JsonProperty("Length")]
		public decimal tbl_parcel_items_parcelLength { get; set; }
		[JsonProperty("Width")]
		public decimal tbl_parcel_items_parcelWidth { get; set; }
		[JsonProperty("Height")]
		public decimal tbl_parcel_items_parcelHeight { get; set; }
		[StringLength(50)]
		[JsonProperty("WeightUnit")]
		public string tbl_parcel_items_parcelWeightUnit { get; set; }
		[StringLength(50)]
		[JsonProperty("DimensionUnit")]
		public string tbl_parcel_items_parcelDimensionUnit { get; set; }
		[JsonProperty("IsDangerousGoods")]
		public bool? tbl_parcel_items_parcelDangerousGoods { get; set; }
		[StringLength(150)]
		[JsonProperty("Description")]
		public string tbl_parcel_items_parcelDescription { get; set; }
		[StringLength(50)]
		[JsonProperty("Type")]
		public string tbl_parcel_items_parcelType { get; set; }
		[StringLength(30)]
		[JsonProperty("ParcelItemReference")]
		public string tbl_parcel_items_parcelReference { get; set; }
		[JsonProperty("Quantity")]
		public int tbl_parcel_items_parcelQty { get; set; }

		[JsonProperty("ParcelItemInfoId")]
		public int? tbl_parcel_items_info_id { get; set; }
		[JsonProperty("ParcelInfoId")]
		public int? tbl_parcel_info_id { get; set; }
		[JsonProperty("ParcelInfoNumber")]
		[StringLength(30)]
		public string tbl_parcel_info_number { get; set; }
		[JsonProperty("ParcelInfo")]
		public virtual tbl_parcel_infoDto tbl_parcel_info { get; set; }

		[JsonProperty("SkuId")]
		public int? tbl_items_sku_id { get; set; }
		[JsonProperty("SKUCode")]
		[StringLength(30)]
		public string SkuCode { get; set; }
        [JsonProperty("SKU")]
		public virtual tbl_items_skuDto tbl_items_sku { get; set; }
	}
}
