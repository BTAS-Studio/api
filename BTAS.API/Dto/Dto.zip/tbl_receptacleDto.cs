﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace BTAS.API.Dto
{
	public class tbl_receptacleDto
	{
		//[JsonProperty("Id")]
		//public int idtbl_receptacle { get; set; }
		[StringLength(50)]
		[JsonProperty("ShipperId")]
		public string tbl_receptacle_shipper_id { get; set; }
		[StringLength(50)]
		[JsonProperty("ReferenceNumber")]
		public string tbl_receptacle_ref { get; set; }
		[StringLength(50)]
		[JsonProperty("Mode")]
		public string tbl_receptacle_mode { get; set; }
		[StringLength(50)]
		[JsonProperty("Type")]
		public string tbl_receptacle_type { get; set; }
		[JsonProperty("NumberOfItems")]
		public int tbl_receptacle_no_items { get; set; }
		[JsonProperty("Weight")]
		public decimal tbl_receptacle_weight { get; set; }
		[StringLength(50)]
		[JsonProperty("Status")]
		public string tbl_receptacle_status { get; set; }
		[StringLength(50)]
		[JsonProperty("Origin")]
		public string tbl_receptacle_origin { get; set; }
		[StringLength(50)]
		[JsonProperty("Destination")]
		public string tbl_receptacle_dest { get; set; }
		[JsonProperty("CreationDate")]
		public DateTime tbl_receptacle_creation { get; set; }
		[JsonProperty("Length")]
		public decimal tbl_receptacle_length { get; set; }
		[JsonProperty("Width")]
		public decimal tbl_receptacle_width { get; set; }
		[JsonProperty("Height")]
		public decimal tbl_receptacle_height { get; set; }

		[JsonProperty("HawbId")]
		public int? tbl_hawb_id { get; set; }
		[JsonProperty("HawbNumber")]
		[StringLength(30)]
		public string HawbNumber { get; set; }
        [JsonProperty("HAWB")]
		public virtual tbl_hawbDto tbl_hawb { get; set; }

		public virtual ICollection<tbl_parcel_infoDto> parcelInfos { get; set; } = new Collection<tbl_parcel_infoDto>();
	}
}
