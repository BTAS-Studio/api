﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using static BTAS.API.Extensions;

namespace BTAS.API.Dto
{
    public class tbl_voyageDto
    {
        //[JsonProperty("Id")]
        //public int idtbl_voyage { get; set; }
        [StringLength(30)]
        [JsonProperty("VoyageNumber")]
        public string tbl_voyage_number { get; set; }
        [NoMap]
        [JsonProperty("Status")]
        [StringLength(50)]
        public string tbl_voyage_status { get; set; }

        [StringLength(50)]
        [JsonProperty("Vessel")]
        public string tbl_voyage_vessel { get; set; }
        [StringLength(30)]
        [JsonProperty("AircraftType")]
        public string tbl_voyage_aircrafType { get; set; }
        [StringLength(30)]
        [JsonProperty("AircraftReg")]
        public string tbl_voyage_aircraftReg { get; set; }
        [StringLength(30)]
        [JsonProperty("VinNumber")]
        public string tbl_voyage_vinNumber { get; set; }
        [StringLength(30)]
        [JsonProperty("LoadPort")]
        public string tbl_voyage_loadPort { get; set; }
        [StringLength(30)]
        [JsonProperty("DischargePort")]
        public string tbl_voyage_dischargePort { get; set; }
        [JsonProperty("ETD")]
        public DateTime tbl_voyage_etd { get; set; }
        [JsonProperty("ETA")]
        public DateTime tbl_voyage_eta { get; set; }
        [JsonProperty("ATD")]
        public DateTime tbl_voyage_atd { get; set; }
        [JsonProperty("ATA")]
        public DateTime tbl_voyage_ata { get; set; }

        public virtual ICollection<tbl_mawbDto> mawbs { get; set; } = new Collection<tbl_mawbDto>();
    }
}
